This is a warmup solution!!
