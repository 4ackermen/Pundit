print(list(map(int, input().split(" "))))
